﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SimpleJSON;
using UnityEngine.UI;
using System.IO;
using UnityEngine.SceneManagement;

public class GameData : MonoBehaviour {

    int score;
    int lvl;


	public void SaveGame()
    {
        GameObject scoreObj = GameObject.Find("SoulsScore");
        Text txt = scoreObj.GetComponent<Text>();
        string scoreStr = txt.text.Replace("Souls: ", "");
        score = int.Parse(scoreStr);

        GameObject lvlObj = GameObject.Find("Lvl");
        txt = lvlObj.GetComponent<Text>();
        string lvlStr = txt.text.Replace("Level: ", "");
        lvl = int.Parse(lvlStr);

        GameObject playerObj = GameObject.Find("Player");

        JSONObject DataJSON = new JSONObject();
        DataJSON.Add("Score", score);
        DataJSON.Add("Level", lvl);

        JSONArray posPlayer = new JSONArray();
        posPlayer.Add(playerObj.transform.position.x);
        posPlayer.Add(playerObj.transform.position.y);
        posPlayer.Add(playerObj.transform.position.z);
        DataJSON.Add("Position", posPlayer);

        string path = Application.persistentDataPath + "/SavedGame.json";
        File.WriteAllText(path, DataJSON.ToString());

    }

    public void LoadGame()
    {
        SceneManager.LoadScene("Level1");
        GameObject playerObj = GameObject.Find("Player");

        string path = Application.persistentDataPath + "/SavedGame.json";
        string data = File.ReadAllText(path);
        JSONObject DataJSON = (JSONObject)JSON.Parse(data);

        score = DataJSON["Score"];
        lvl = DataJSON["Level"];

        GameObject scoreObj = GameObject.Find("SoulsScore");
        Text scoreText = scoreObj.GetComponent<Text>();
        scoreText.text = "Souls: " + score.ToString();

        GameObject lvlObj = GameObject.Find("Lvl");
        Text lvlText = lvlObj.GetComponent<Text>();
        lvlText.text = "Level: " + lvl.ToString();

        /*playerObj.transform.position = new Vector3(
                DataJSON["Position"].AsArray[0],
                DataJSON["Position"].AsArray[1],
                DataJSON["Position"].AsArray[2]
            );*/
    }
}

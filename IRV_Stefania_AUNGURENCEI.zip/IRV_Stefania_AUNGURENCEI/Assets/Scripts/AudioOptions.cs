﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class AudioOptions : MonoBehaviour {

    public AudioMixer audioMix;
    public Slider VolumeSlider;
    public Slider MusicSlider;
    public Slider SFXSlider;
    public Slider VoiceSlider;

    private void Awake()
    {
        float musicVolume = MusicSlider.value * 80f - 80f;
        audioMix.SetFloat("BGMusic", musicVolume);

        float SFXVolume = SFXSlider.value * 80f - 80f;
        audioMix.SetFloat("SFX", SFXVolume);

        float VoiceVolume = VoiceSlider.value * 80f - 80f;
        audioMix.SetFloat("Voice", VoiceVolume);

        float volume = VolumeSlider.value * 80f - 80f;
        audioMix.SetFloat("Volume", volume);
    }

    public void SetMasterVolume(float volume)
    {
        float masterVolume = volume * 80f - 80f;
        audioMix.SetFloat("Volume", masterVolume);
    }

    public void SetMusicVolume(float volume)
    {
        float musicVolume = volume * 80f - 80f;
        audioMix.SetFloat("BGMusic", musicVolume);
    }

    public void SetSFXVolume(float volume)
    {
        float SFXVolume = volume * 80f - 80f;
        audioMix.SetFloat("SFX", SFXVolume);
    }

    public void SetVoiceVolume(float volume)
    {
        float voiceVolume = volume * 80f - 80f;
        audioMix.SetFloat("Voice", voiceVolume);
    }

    public void ExitToMain()
    {
        SceneManager.LoadScene("MainMenu");
    }
}

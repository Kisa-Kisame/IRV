﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour {

    //GameManager gameMngr;

	public void NewGame()
    {
        SceneManager.LoadScene("Level1");
        /*
        GameManager manager = GameObject.Find("GameManager").GetComponent<GameManager>();
        manager.SetGameManagerState(GameManager.GameManagerState.LoadLevel1);
        */
    }

    
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    private CharacterController charController;
    private ParticleSystem lvlUpEffect;

    public float speed;
    public float jumpHeight;
    public GameObject LvlTextObj;
    public GameObject CollectMsg;
    public GameObject ScoreTextObj;

    int score;
    int lvl;
    Text scoreText;

    Text lvlText;
    // Use this for initialization
    private void Awake()
    {
        lvl = 1;
        scoreText = ScoreTextObj.GetComponent<Text>();
        scoreText.text = "Souls: " + score.ToString();

        lvlText = LvlTextObj.GetComponent<Text>();
        lvlText.text = "Level: " + lvl.ToString();
    }

    void Start () {
        charController = GetComponent<CharacterController>();
        lvlUpEffect = GetComponent<ParticleSystem>();
    }
	
	// Update is called once per frame
	void Update ()
    {     
        //float moveX = Input.GetAxis("Horizontal") * Time.deltaTime * speed;
        //float moveZ = Input.GetAxis("Vertical") * Time.deltaTime * speed;
        float jump = jumpHeight * Input.GetAxis("Jump") * Time.deltaTime * 5f;
        Vector3 movement; // = new Vector3(moveX, jump, moveZ);

        movement = (transform.forward * Input.GetAxis("Vertical")) + (transform.right * Input.GetAxis("Horizontal"));
        movement = movement.normalized * speed;
        movement.y = jump;

        charController.Move(movement);

    }

    public void LevelUp()
    {
        lvlUpEffect.Play();
    }

    public void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Soul")
        {
            score++;
            scoreText.text = "Souls: " + score.ToString();

            if (score == 5 * lvl)
            {
                lvl++;
                lvlText.text = "Level: " + lvl.ToString();
                LevelUp();
            }

            GameObject gameCanvas = GameObject.Find("Canvas");
            GameObject soulMsg = Instantiate(CollectMsg);
            soulMsg.transform.SetParent(gameCanvas.transform, false);
            soulMsg.transform.Translate(0, 45, 0);
            Destroy(soulMsg, 1f);
        }
    }
}

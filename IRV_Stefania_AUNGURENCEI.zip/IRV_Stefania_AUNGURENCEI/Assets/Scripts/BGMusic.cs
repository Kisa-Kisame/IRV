﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class BGMusic : MonoBehaviour {

    //public AudioMixer audioMix;
    //public Slider MusicSlider;

    private void Awake()
    {

        GameObject[] objs = GameObject.FindGameObjectsWithTag("BGMusic");
        if(objs.Length > 1)
        {
            Destroy(this.gameObject);
        }

        DontDestroyOnLoad(this.gameObject);
        
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

    public Transform player;
    public Vector3 offset;
    public float zoomSpeed;
    public float rotateSpeed;
    public float minZoom = 1f;
    public float maxZoom = 3f;

    private float zoom = 1f;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        zoom -= Input.GetAxis("Mouse ScrollWheel") * zoomSpeed;
        zoom = Mathf.Clamp(zoom, minZoom, maxZoom);

        if (Input.GetKey(KeyCode.Mouse1))
        {
            player.Rotate(0f, Input.GetAxis("Mouse X") * rotateSpeed, 0f);
            //Debug.Log("aici");
        }
        Quaternion rotation = Quaternion.Euler(0, player.eulerAngles.y ,0);

        transform.position = player.position + (rotation * offset * zoom);

        //transform.position = player.position + offset * zoom;

        transform.LookAt(player);
	}

}

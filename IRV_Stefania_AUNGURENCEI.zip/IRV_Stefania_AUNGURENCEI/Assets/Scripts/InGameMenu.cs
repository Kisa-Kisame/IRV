﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InGameMenu : MonoBehaviour {

    public static bool InGameMenuActive = false;
    public GameObject MenuCanvas;

    private void Start()
    {
        MenuCanvas.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            //Debug.Log(InGameMenuActive);

            if (InGameMenuActive == true)
            {
                MenuCanvas.gameObject.SetActive(false);
                InGameMenuActive = false;
            }
            else
            {
                MenuCanvas.gameObject.SetActive(true);
                InGameMenuActive = true;
            }

        }
    }
}
